﻿using AutoMapper;

namespace Invoices
{
    public class InvoicesProfile : Profile
    {
        public InvoicesProfile()
        {
           
        }
    }
}
